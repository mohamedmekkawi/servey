﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace RegritrationCRUD
{
    /// <summary>
    /// Interaction logic for AddSurvey.xaml
    /// </summary>
    public partial class AddSurvey : Window
    {
        public AddSurvey()
        {
            InitializeComponent();
            gridQuestionNumber.Visibility = Visibility.Visible;
            comboanswer.Items.Add("A");
            comboanswer.Items.Add("B");
            //comboanswer.Items.Add("C");
            //comboanswer.Items.Add("D");
        }

        private void questionNumber_Click(object sender, RoutedEventArgs e)
        {
            gridQuestionNumber.Visibility = Visibility.Visible;
            gridQuestion.Visibility = Visibility.Collapsed;
            gridFirstChoice.Visibility = Visibility.Collapsed;
            gridSecondChoice.Visibility = Visibility.Collapsed;
            gridThirdChoice.Visibility = Visibility.Collapsed;
            gridFourthChoice.Visibility = Visibility.Collapsed;
            gridAnswer.Visibility = Visibility.Collapsed;

        }

        private void question_Click(object sender, RoutedEventArgs e)
        {
            gridQuestionNumber.Visibility = Visibility.Collapsed;
            gridQuestion.Visibility = Visibility.Visible;
            gridFirstChoice.Visibility = Visibility.Collapsed;
            gridSecondChoice.Visibility = Visibility.Collapsed;
            gridThirdChoice.Visibility = Visibility.Collapsed;
            gridFourthChoice.Visibility = Visibility.Collapsed;
            gridAnswer.Visibility = Visibility.Collapsed;
        }

        private void firstChoice_Click(object sender, RoutedEventArgs e)
        {
            gridQuestionNumber.Visibility = Visibility.Collapsed;
            gridQuestion.Visibility = Visibility.Collapsed;
            gridFirstChoice.Visibility = Visibility.Visible;
            gridSecondChoice.Visibility = Visibility.Collapsed;
            gridThirdChoice.Visibility = Visibility.Collapsed;
            gridFourthChoice.Visibility = Visibility.Collapsed;
            gridAnswer.Visibility = Visibility.Collapsed;
        }

        private void secondChoice_Click(object sender, RoutedEventArgs e)
        {
            gridQuestionNumber.Visibility = Visibility.Collapsed;
            gridQuestion.Visibility = Visibility.Collapsed;
            gridFirstChoice.Visibility = Visibility.Collapsed;
            gridSecondChoice.Visibility = Visibility.Visible;
            gridThirdChoice.Visibility = Visibility.Collapsed;
            gridFourthChoice.Visibility = Visibility.Collapsed;
            gridAnswer.Visibility = Visibility.Collapsed;
        }

        private void thirdChoice_Click(object sender, RoutedEventArgs e)
        {
            gridQuestionNumber.Visibility = Visibility.Collapsed;
            gridQuestion.Visibility = Visibility.Collapsed;
            gridFirstChoice.Visibility = Visibility.Collapsed;
            gridSecondChoice.Visibility = Visibility.Collapsed;
            gridThirdChoice.Visibility = Visibility.Visible;
            gridFourthChoice.Visibility = Visibility.Collapsed;
            gridAnswer.Visibility = Visibility.Collapsed;
        }

        private void fourthChoice_Click(object sender, RoutedEventArgs e)
        {
            gridQuestionNumber.Visibility = Visibility.Collapsed;
            gridQuestion.Visibility = Visibility.Collapsed;
            gridFirstChoice.Visibility = Visibility.Collapsed;
            gridSecondChoice.Visibility = Visibility.Collapsed;
            gridThirdChoice.Visibility = Visibility.Collapsed;
            gridFourthChoice.Visibility = Visibility.Visible;
            gridAnswer.Visibility = Visibility.Collapsed;
        }

        private void answer_Click(object sender, RoutedEventArgs e)
        {
            gridQuestionNumber.Visibility = Visibility.Collapsed;
            gridQuestion.Visibility = Visibility.Collapsed;
            gridFirstChoice.Visibility = Visibility.Collapsed;
            gridSecondChoice.Visibility = Visibility.Collapsed;
            gridThirdChoice.Visibility = Visibility.Collapsed;
            gridFourthChoice.Visibility = Visibility.Collapsed;
            gridAnswer.Visibility = Visibility.Visible;
        }

        private void save_Click(object sender, RoutedEventArgs e)
        {
            if (
                // Validate information
                txtQuestion.Text != "" &&
                txtFirstChoice.Text != "" &&
                txtSecondChoice.Text != "" &&
                txtThirdChoice.Text != "" &&
                txtFourthChoice.Text != ""
                // TODO: comboanswer.Text != "" &&
                )
            {
                // Create the connexion to our database calling info from app.config
                SqlConnection conn = new SqlConnection(ConfigurationManager.ConnectionStrings["connexion"].ConnectionString);

                // Create the SqlCommand = connexion
                using (SqlCommand command = conn.CreateCommand())
                {
                    // Generate insert = Sql Server
                    command.CommandText = "insert into NewSurvey(question, firstchoice, secondchoice, thirdchoice, fourthchoice, answer)values(@question, @firstchoice, @secondchoice, @thirdchoice, @fourthchoice, @answer)";

                    // Asign insert variables (values of the survey) 
                    //command.Parameters.AddWithValue("@number", int.Parse(txtQuestionNumber.Text));
                    command.Parameters.AddWithValue("@question", txtQuestion.Text);
                    command.Parameters.AddWithValue("@firstChoice", txtFirstChoice.Text);
                    command.Parameters.AddWithValue("@secondChoice", txtSecondChoice.Text);
                    command.Parameters.AddWithValue("@thirdChoice", txtThirdChoice.Text);
                    command.Parameters.AddWithValue("@fourthChoice", txtFourthChoice.Text);
                    command.Parameters.AddWithValue("@answer", comboanswer.SelectedValue.ToString());

                    // Open the connexion
                    conn.Open();

                    // Command.ExecuteNonQuery() ? = gave us the number of afected lines
                    int status = command.ExecuteNonQuery();

                    // If > 0, the user has been registered
                    if (status > 0)
                    {
                        txtStatus.Text = "Survey has been register";
                    }
                    else
                    {
                        txtStatus.Text = "Something is wrong";
                    }
                }

                // Close connexion 
                conn.Close();
            }
            else
            {
                // If the user is missing any information
                txtStatus.Text = "Please insert all information to continue";
            }
        }

        // TODO validate numbers || Investigate code
        // if (e.Key >= Key.D0 && e.Key <= Key.D9 || e.Key >= Key.NumPad0 && e.Key <= Key.NumPad9)

    }
}
