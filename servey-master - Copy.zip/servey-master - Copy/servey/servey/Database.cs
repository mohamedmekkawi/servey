﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace servey
{
    //class Database
    //{
    //    private string CONN_STRING = @"Server=tcp:sstorage.database.windows.net,1433;Initial Catalog=survey;Persist Security Info=False;User ID={sqladmin};Password={Project1};MultipleActiveResultSets=False;Encrypt=True;TrustServerCertificate=False;Connection Timeout=30;";
    //}
}
