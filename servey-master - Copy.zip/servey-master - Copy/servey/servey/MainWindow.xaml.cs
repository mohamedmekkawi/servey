﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace servey
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public object NavigationService { get; private set; }

        public MainWindow()
        {
            InitializeComponent();
            SqlConnection conn = new SqlConnection(ConfigurationManager.ConnectionStrings["connexion"].ConnectionString);
            conn.Open();

            conn.Close();

        }

        private void btStartSurvey_Click(object sender, RoutedEventArgs e)
        {
            Window1 windo = new Window1();
            windo.Show();
            this.Close();
        }

        private void btViewResult_Click(object sender, RoutedEventArgs e)
        {
            ViewResult windo = new ViewResult();
            windo.Show();
            this.Close();
        }

        private void btAddNewSurvey_Click(object sender, RoutedEventArgs e)
        {
            AddNewSurvey windo = new AddNewSurvey();
            windo.Show();
            this.Close();
        }

        private void info_Click(object sender, RoutedEventArgs e)
        {
            info modal = new info();
            modal.Owner = this;
            ApplyEffect(this);

            modal.ShowDialog();
            bool? result = modal.DialogResult;
            if (result != null)
            {
                if (result == false)
                {
                    Removeeffect(this);
                }
            }

        }

        private void ApplyEffect(Window win)
        {
            var effect = new System.Windows.Media.Effects.BlurEffect();
            effect.Radius = 5;
            win.Effect = effect;
        }
        public void Removeeffect(Window win)
        {
            win.Effect = null;
        }
    }
}
