﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace servey
{
    /// <summary>
    /// Interaction logic for Window1.xaml
    /// </summary>
    public partial class Window1 : Window
    {
        public Window1()
        {
            InitializeComponent();

        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            //validate the information
            if (
                tbname.Text != "" &&
                tbphone.Text != "" &&
                tbage.Text != ""
                )     
            {

                //creamos la conexión a nuestra base de datos llamando la información de app.config
                SqlConnection conn = new SqlConnection(ConfigurationManager.ConnectionStrings["connexion"].ConnectionString); 


                //creamos el sqlcommand e igualamos a la conexión
                using (SqlCommand command = conn.CreateCommand()) 

                {

                    //generamos la sentencia insert, igual que en SQL Server
                    command.CommandText = "insert into RegisterUser(name, phone, age)values(@name, @phone, @age)"; 
                    

                    //Asignamos a las variables de inserción los valores del formulario
                    command.Parameters.AddWithValue("@name", tbname.Text);
                    command.Parameters.AddWithValue("@phone", tbphone.Text);
                    command.Parameters.AddWithValue("@age", int.Parse(tbage.Text));


                    //abrimos la conexión
                    conn.Open();

                    // command.ExecuteNonQuery() nos devuelve el número de líneas afectadas
                   int status = command.ExecuteNonQuery();

                    //Sí es mayor a 0, el usuario se ha registrado

                    if (status > 0)

                    {

                        txtstatus.Text = "Usuario registrado con éxito";
                       

                    }

                    else

                    {

                        txtstatus.Text = "Algo fallo";

                    }

                }

                //se cierra la conexión

                conn.Close();

            }

            else //notifica al usuario de que falta ingresar alguna información

            {

                txtstatus.Text = "Debes ingresar toda la información para poder continuar con el registro";

            }

            Window2 windo = new Window2();
            windo.Show();
            this.Close();

        }
    }

    //private void Btwin1Back_Click(object sender, RoutedEventArgs e)
    //{
    //    MainWindow windo = new MainWindow();
    //    windo.Show();
    //    this.Close();
    //}
}

